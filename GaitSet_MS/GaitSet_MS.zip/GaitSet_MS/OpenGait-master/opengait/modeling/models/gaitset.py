import torch
import copy
import torch.nn as nn

from ..base_model import BaseModel
from ..modules import SeparateFCs, BasicConv2d, SetBlockWrapper, HorizontalPoolingPyramid, PackSequenceWrapper
import numpy as np


class GaitSet(BaseModel):
    """
        GaitSet: Regarding Gait as a Set for Cross-View Gait Recognition
        Arxiv:  https://arxiv.org/abs/1811.06186
        Github: https://github.com/AbnerHqC/GaitSet
    """

    def build_network(self, model_cfg):
        in_c = model_cfg['in_channels']
        self.set_block1 = nn.Sequential(BasicConv2d(in_c[0], in_c[1], 5, 1, 2),
                                        nn.LeakyReLU(inplace=True),
                                        BasicConv2d(in_c[1], in_c[1], 3, 1, 1),
                                        nn.LeakyReLU(inplace=True),
                                        nn.MaxPool2d(kernel_size=2, stride=2))

        self.set_block2 = nn.Sequential(BasicConv2d(in_c[1], in_c[2], 3, 1, 1),
                                        nn.LeakyReLU(inplace=True),
                                        BasicConv2d(in_c[2], in_c[2], 3, 1, 1),
                                        nn.LeakyReLU(inplace=True), )
        # nn.MaxPool2d(kernel_size=2, stride=2))

        self.set_block3 = nn.Sequential(BasicConv2d(in_c[2], in_c[3], 3, 1, 1),
                                        nn.LeakyReLU(inplace=True),
                                        BasicConv2d(in_c[3], in_c[3], 3, 1, 1),
                                        nn.LeakyReLU(inplace=True))

        self.gl_block2 = copy.deepcopy(self.set_block2)
        self.gl_block3 = copy.deepcopy(self.set_block3)

        self.set_block1 = SetBlockWrapper(self.set_block1)
        self.set_block2 = SetBlockWrapper(self.set_block2)
        self.set_block3 = SetBlockWrapper(self.set_block3)

        self.set_pooling = PackSequenceWrapper(torch.max)

        self.Head = SeparateFCs(**model_cfg['SeparateFCs'])

        self.HPP = HorizontalPoolingPyramid(bin_num=model_cfg['bin_num'])

        self.connect_joint = np.array([5, 0, 0, 1, 2, 0, 0, 5, 6, 7, 8, 5, 6, 11, 12, 13, 14])
        self.symmetry_joint = np.array([0, 2, 1, 4, 3, 6, 5, 8, 7, 10, 9, 12, 11, 14, 13, 16, 15])

    def forward(self, inputs):
        ipts, labs, _, _, seqL = inputs

        # (128,30,17,2)
        sils = ipts[0]  # [n, s, h, w]

        if len(sils.size()) == 4:
            sils = sils.unsqueeze(1)

        del ipts

        embs = 0
        for stream in range(3):
            n, c1, t, v, c = sils.size()

            if stream == 0:
                x = sils.clone()
            if stream == 1:         # Bone
                # sils_2 = torch.zeros_like(sils)
                sils_2 = sils.clone()
                for i in range(v):
                    sils_2[:, :, :, i, :2] = sils[:, :, :, i, :2] - sils[:, :, :, self.connect_joint[i], :2]
                x = sils_2

            # elif stream == 1:       # Velocity
            #     if t > 1:
            #         sils_3 = sils.clone()
            #         for tt in range(t-1):
            #             sils_3[:, :, tt, :, :] = sils[:, :, tt+1, :, :] - sils[:, :, tt, :, :]
            #         x = sils_3

            elif stream == 2:       # Symmetry
                sils_4 = sils.clone()
                for i in range(v):
                    sils_4[:, :, :, i, :2] = sils[:, :, :, i, :2] - sils[:, :, :, self.symmetry_joint[i], :2]
                x = sils_4

            outs = self.set_block1(x)

            outs = self.set_block1(sils)
            gl = self.set_pooling(outs, seqL, options={"dim": 2})[0]
            gl = self.gl_block2(gl)

            outs = self.set_block2(outs)
            gl = gl + self.set_pooling(outs, seqL, options={"dim": 2})[0]
            gl = self.gl_block3(gl)

            outs = self.set_block3(outs)
            outs = self.set_pooling(outs, seqL, options={"dim": 2})[0]
            gl = gl + outs

            # Horizontal Pooling Matching, HPM
            feature1 = self.HPP(outs)  # [n, c, p]
            feature2 = self.HPP(gl)  # [n, c, p]
            feature = torch.cat([feature1, feature2], -1)  # [n, c, p]

            embs = embs + self.Head(feature)



        n, _, s, h, w = sils.size()
        retval = {
            'training_feat': {
                'triplet': {'embeddings': embs, 'labels': labs}
            },
            'visual_summary': {
                'image/sils': sils.view(n * s, 1, h, w)
            },
            'inference_feat': {
                'embeddings': embs
            }
        }
        return retval
