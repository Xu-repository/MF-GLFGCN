from .metric import mean_iou
from numpy import set_printoptions
set_printoptions(suppress=True, formatter={'float': '{:0.2f}'.format})
